import React from "react";

const NotFound = () => {
  return (
    <div className="container my-4">
      <h1>Page Not found</h1>
    </div>
  );
};

export default NotFound;
