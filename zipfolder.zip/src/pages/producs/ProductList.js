import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./productlist.css";

function ProductList() {
  const [products, setProducs] = useState([
    { id: 12, name: "Mclin", area: 2340, price: 23000 },
    { id: 11, name: "kithav", area: 2340, price: 23000 },
    { id: 10, name: "Lokeshnakh", area: 2340, price: 23000 },
    { id: 9, name: "Central Heating", area: 2340, price: 23000 },
    { id: 8, name: "Air Conditioning", area: 2340, price: 23000 },
  ]);

  const [filterdata, setfilterData] = useState(ProductList);

  //   const getProduct = () => {
  //     fetch("")
  //       .then((response) => {
  //         if (response.ok) {
  //           return response.json;
  //         }
  //         throw new Error();
  //       })
  //       .then((data) => {
  //         setProducs(data);
  //       })
  //       .catch((error) => {
  //         alert("unable to get data");
  //       });
  //   };

  //   useEffect (getProducs,[])
  return (
    <div className="container my-4">
      <h2 className="text-center mb-4 ">Products</h2>

      <div className=" create ">
        <input type="text" placeholder="search" className="search" />

        <Link className="btn btn-primary me-2" to="/create" role="button">
          Create Product
        </Link>
        <button type="button" className="btn btn-outline-primary">
          {" "}
          {/* onclick={getProducts} */}
          Reload
        </button>

        <div className="col "></div>
      </div>
      <div className="">
        <table className="table ">
          <thead className="">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>area</th>
              <th>price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product, index) => {
              return (
                <tr key={index}>
                  <td>{product.id}</td>
                  <td>{product.name}</td>
                  <td>{product.area}</td>
                  <td>{product.price}</td>

                  <td style={{ width: "10px", whiteSpace: "nowrap" }}>
                    <Link
                      className="btn btn-primary btn-sm me-1"
                      to={"/product/edit/" + product.id}
                    >
                      Edit
                    </Link>
                    <button type="button" className="btn btn-danger btn-sm">
                      delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ProductList;
