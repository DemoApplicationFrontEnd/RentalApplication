import React, { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
const EditProduct = () => {
  const params = useParams();
  const [validationErrors, setValidationErrors] = useState({});
  const navigate = useNavigate();
  async function handleSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const product = Object.fromEntries(formData.entries());

    if (
      !product.id ||
      !product.name ||
      !product.area ||
      !product.price ||
      !product.catagory ||
      !product.discription
    ) {
      alert("please fill the all input fields");
      return;
    }

    // try {
    //   const response = await fetch("http://localhost:4000/products", {
    //     method: "PATCH",
    //     body: formData,
    //   });
    //   const data = await response.json();
    //   if (response.ok) {
    //     //product created correctly need to navigate to product list Page
    //     navigate("/products");
    //   } else if (response.status === 400) {
    //     alert("validation error");
    //     //need to set validation error which is coming from backend
    //     //example : setValidationError(data)
    //   } else {
    //     alert("unable to create the products");
    //   }
    // } catch (error) {
    //   alert("unable to connect to the server");
    // }
  }
  return (
    <div className="container my-4">
      <div className="row">
        <div className="col-md-8 mx-auto rounded border p-4">
          <h2 className="text-center mb-5">Edit Product</h2>

          <div className="row mb-3">
            <label className="col-sm-4 col-form-lable">Id</label>
            <div className="col-sm-8">
              <input
                readOnly
                className="form-control "
                defaultValue={params.id}
              />
              {/* <span className="text-danger">{validationErrors.id}</span> */}
              {/* used to display any validation error validationError is use state and variable name is coming from the server which is set for name input error in backend  */}
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="row mb-3">
              <label className="col-sm-4 col-form-lable">Name</label>
              <div className="col-sm-8">
                <input className="form-control " name="name" />
                <span className="text-danger"></span>
                {/* used to display any validation error  */}
              </div>
            </div>

            <div className="row mb-3">
              <label className="col-sm-4 col-form-lable">Area</label>
              <div className="col-sm-8">
                <input className="form-control " name="area" />
                <span className="text-danger"></span>
                {/* used to display any validation error  */}
              </div>
            </div>

            <div className="row mb-3">
              <label className="col-sm-4 col-form-lable">Price</label>
              <div className="col-sm-8">
                <input className="form-control " name="price" />
                <span className="text-danger"></span>
                {/* used to display any validation error  */}
              </div>
            </div>

            <div className="row mb-3">
              <label className="col-sm-4 col-form-lable">Catagory</label>
              <div className="col-sm-8">
                <select className="form-select" name="catagory">
                  <option value="other">other</option>
                  <option value="other">1BHK</option>
                  <option value="other">2BHK</option>
                  <option value="other">Villa</option>
                </select>
                <span className="text-danger"></span>
                {/* used to display any validation error  */}
              </div>
            </div>

            <div className="row mb-3">
              <label className="col-sm-4 col-form-lable">Discription</label>
              <div className="col-sm-8">
                <textarea
                  className="form-control "
                  name="discription"
                  rows="4"
                />
                <span className="text-danger"></span>
                {/* used to display any validation error  */}
              </div>
            </div>

            <div className="row mb-3">
              <label className="col-sm-4 col-form-lable">Image</label>
              <div className="col-sm-8">
                <input className="form-control " type="file" name="img" />
                <span className="text-danger"></span>
                {/* used to display any validation error  */}
              </div>
            </div>

            <div className="row">
              <div className="offset-sm-4 col-sm-4 d-grid">
                <button type="submit" className="btn btn-primary">
                  Submit
                </button>
              </div>
              <div className="col-sm d-grid">
                <Link
                  className="btn btn-secondary"
                  to="/products"
                  role="button"
                >
                  Cancel
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditProduct;
