import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const CreateProduct = () => {
  const navigate = useNavigate();
  const [values, setValues] = useState({
    id: "",
    name: "",
    area: "",
    price: "",
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    axios.post("http://localhost:3004/posts", values).then((res) => {
      console.log(res);
      navigate("/Products");
    });
  };

  return (
    <div className="container my-4">
      <div className="row">
        <div className="col-md-8 mx-auto rounded border p-4 shadow">
          <h2 className="text-center mb-4">Create Product</h2>

          <form onSubmit={handleSubmit}>
            <div className="mb-3 row">
              <label className="col-sm-2 col-form-label">ID</label>
              <div className="col-sm-10">
                <input
                  className="form-control"
                  name="id"
                  onChange={(e) => setValues({ ...values, id: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="mb-3 row">
              <label className="col-sm-2 col-form-label">Name</label>
              <div className="col-sm-10">
                <input
                  className="form-control"
                  name="name"
                  onChange={(e) =>
                    setValues({ ...values, name: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            <div className="mb-3 row">
              <label className="col-sm-2 col-form-label">Area</label>
              <div className="col-sm-10">
                <input
                  className="form-control"
                  name="area"
                  onChange={(e) =>
                    setValues({ ...values, area: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            <div className="mb-3 row">
              <label className="col-sm-2 col-form-label">Price</label>
              <div className="col-sm-10">
                <input
                  className="form-control"
                  name="price"
                  onChange={(e) =>
                    setValues({ ...values, price: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            <div className="row">
              <div className="offset-sm-2 col-sm-4 d-grid">
                <button type="submit" className="btn btn-primary">
                  Submit
                </button>
              </div>
              <div className="col-sm-4 d-grid">
                <Link
                  className="btn btn-secondary"
                  to="/products"
                  role="button"
                >
                  Cancel
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateProduct;
