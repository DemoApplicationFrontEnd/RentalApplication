import React from 'react'

function Data() {
  const data=[{ id: 12, name: "Mclin", area: 2340, price: 23000 },
    { id: 11, name: "kithav", area: 2340, price: 23000 },
    { id: 10, name: "Lokeshnakh", area: 2340, price: 23000 },
    { id: 9, name: "Central Heating", area: 2340, price: 23000 },
    { id: 8, name: "Air Conditioning", area: 2340, price: 23000 }]

  return (
    <div>
      
    </div>
  )
}

export default Data
