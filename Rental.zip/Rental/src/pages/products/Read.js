import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import "./Read.css"; // Import the CSS file

function Read() {
  const [data, setData] = useState({});
  const { id } = useParams();

  const fetchData = async () => {
    try {
      const response = await axios.get(`http://localhost:3004/posts/${id}`);
      setData(response.data);
      console.log(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  return (
    <div className="w-50 border bg-white shadow px-5 pt-4 pb-5 rounded read-card">
      <h3 className="text-center mb-4">User Details</h3>
      <div className="mb-3">
        <strong>Name:</strong> <span>{data.name}</span>
      </div>
      <div className="mb-3">
        <strong>Area:</strong> <span>{data.area}</span>
      </div>
      <div className="mb-3">
        <strong>Price:</strong> <span>{data.price}</span>
      </div>
      <div className="d-flex justify-content-center mt-4">
        <Link to={`/product/update/${id}`} className="btn btn-success me-3">
          Edit
        </Link>
        <Link to="/products" className="btn btn-primary">
          Back
        </Link>
      </div>
    </div>
  );
}

export default Read;
