import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./productlist.css";
import axios from "axios";

function ProductList() {
  const [value, setValue] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredProducts, setFilteredProducts] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:3004/posts");
      setValue(response.data);
      setFilteredProducts(response.data); 
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const deleteProduct = async (id) => {
    try {
      await axios.delete(`http://localhost:3004/posts/${id}`);
      fetchData();
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  const handleSearch = (event) => {
    const term = event.target.value.toLowerCase();
    setSearchTerm(term);
    const filtered = value.filter((product) =>
      product.name.toLowerCase().includes(term)
    );
    setFilteredProducts(filtered);
  };

  return (
    <div className="container my-4">
      <h2 className="text-center mb-4">Products</h2>

      <div className="d-flex justify-content-between mb-3">
        <input
          type="text"
          placeholder="Search"
          className="form-control me-2"
          value={searchTerm}
          onChange={handleSearch}
        />
        <div>
          <Link className="btn btn-primary me-2" to="/create">
            Create Product
          </Link>
          <button
            type="button"
            className="btn btn-outline-primary"
            onClick={fetchData}
          >
            Reload
          </button>
        </div>
      </div>

      <div>
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Area</th>
              <th>Price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.map((product) => (
              <tr key={product.id}>
                <td>{product.id}</td>
                <td>{product.name}</td>
                <td>{product.area}</td>
                <td>{product.price}</td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <Link
                    className="btn btn-info btn-sm me-1"
                    to={`/product/read/${product.id}`}
                  >
                    Read
                  </Link>
                  <Link
                    className="btn btn-primary btn-sm me-1"
                    to={`/product/edit/${product.id}`}
                  >
                    Edit
                  </Link>
                  <button
                    onClick={() => deleteProduct(product.id)}
                    type="button"
                    className="btn btn-danger btn-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ProductList;
