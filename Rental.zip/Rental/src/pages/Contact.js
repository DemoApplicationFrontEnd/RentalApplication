import React from "react";

function Contact() {
  return (
    <div className="container my-4">
      <h2>contact us</h2>
    </div>
  );
}

export default Contact;
