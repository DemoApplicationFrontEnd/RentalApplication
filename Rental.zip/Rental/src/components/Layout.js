import React, { useState } from "react";
import logo from "./Assets/logo.png";
import { Link } from "react-router-dom";
import "./Layout.css"; // Import the CSS file

export const Layout = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-white border-bottom box-shadow sticky-top">
        <div className="container">
          <Link className="navbar-brand" to="/">
            <img src={logo} alt="Logo" width="30" className="me-2" />
            Admin Dashboard
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link text-dark" aria-current="page" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-dark" to="/contact">
                  Contact
                </Link>
              </li>
              <li
                className="nav-item dropdown"
                onMouseEnter={toggleDropdown}
                onMouseLeave={toggleDropdown}
              >
                <a
                  className={`nav-link dropdown-toggle text-dark ${
                    isOpen ? "active" : ""
                  }`}
                  href="#"
                  role="button"
                  aria-expanded={isOpen}
                  onClick={toggleDropdown}
                >
                  RealEstate
                  {/* <span
                    className={`dropdown-icon ${isOpen ? "rotate" : ""}`}
                  ></span> */}
                </a>
                {isOpen && (
                  <ul className="dropdown-menu fade-in">
                    <li>
                      <Link className="dropdown-item" to="/products">
                        Products
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/projects">
                        Projects
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/features">
                        Features
                      </Link>
                    </li>
                  </ul>
                )}
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
};
