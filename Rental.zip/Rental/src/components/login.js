import React from 'react';
import './login.css';


function login(){

    return(
        <div>Hello</div>
    )
}


    
 export default login